import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required");

  const client = new pg.Client({
    connectionString,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  const result = await client.query("select current_database() as database, current_user as user, now() as now");
  console.log(result.rows[0]);
  await client.end();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
