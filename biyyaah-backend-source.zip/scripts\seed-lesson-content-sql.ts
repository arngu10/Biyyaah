import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

type SectionSeed = {
  title: string;
  [key: string]: unknown;
};

type VocabularySeed = {
  arabic: string;
  dutchMeaning: string;
  transliteration?: string;
  notes?: string;
};

type PronunciationPromptSeed = {
  expectedText: string;
  dutchMeaning?: string;
  transliteration?: string;
};

type ExerciseQuestionSeed = {
  prompt: string;
  correctAnswer: string;
  choices?: string[];
  explanation?: string;
};

type ExerciseSeed = {
  type: "multiple_choice" | "fill_blank" | "matching" | "translation" | "written";
  prompt: string;
  questions: ExerciseQuestionSeed[];
};

type LessonContentSeed = {
  moduleNumber: number;
  lessonNumber: number;
  title?: string;
  sourcePages: number[];
  sections: Record<"grammar" | "vocabulary" | "exercises" | "summary" | "pronunciation", SectionSeed>;
  vocabulary: VocabularySeed[];
  pronunciationPrompts: PronunciationPromptSeed[];
  exercises: ExerciseSeed[];
};

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required");

  const seedFileName = process.argv[2] ?? "lesson-1-content.json";
  const seedPath = join(__dirname, "..", "prisma", "seed-data", seedFileName);
  const seed = JSON.parse(readFileSync(seedPath, "utf-8")) as LessonContentSeed;
  const client = new pg.Client({
    connectionString,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  await client.query("begin");

  const lessonResult = await client.query<{ id: string }>(
    `
      select l."id"
      from "Lesson" l
      join "Module" m on m."id" = l."moduleId"
      join "Course" c on c."id" = m."courseId"
      where c."slug" = $1 and m."moduleNumber" = $2 and l."lessonNumber" = $3
    `,
    ["biyyaah-medina-arabic", seed.moduleNumber, seed.lessonNumber],
  );

  const lessonId = lessonResult.rows[0]?.id;
  if (!lessonId) {
    throw new Error(`Lesson not found: module ${seed.moduleNumber}, lesson ${seed.lessonNumber}`);
  }

  if (seed.title) {
    await client.query(
      `
        update "Lesson"
        set "title" = $1, "updatedAt" = now()
        where "id" = $2
      `,
      [seed.title, lessonId],
    );
  }

  for (const [index, [type, section]] of Object.entries(seed.sections).entries()) {
    const sectionContent = JSON.stringify({ ...section, sourcePages: seed.sourcePages });
    const sectionResult = await client.query(
      `
        update "LessonSection"
        set "title" = $1, "orderIndex" = $2, "contentJson" = $3::jsonb, "updatedAt" = now()
        where "lessonId" = $4 and "type" = $5::"LessonSectionType"
      `,
      [section.title, index, sectionContent, lessonId, type],
    );

    if (sectionResult.rowCount === 0) {
      await client.query(
        `
          insert into "LessonSection" (
            "id", "lessonId", "type", "title", "orderIndex", "contentJson", "createdAt", "updatedAt"
          )
          values ($1, $2, $3, $4, $5, $6::jsonb, now(), now())
        `,
        [randomUUID(), lessonId, type, section.title, index, sectionContent],
      );
    }
  }

  await client.query(`delete from "ExerciseAttempt" where "lessonId" = $1`, [lessonId]);
  await client.query(
    `
      delete from "ExerciseQuestion"
      where "exerciseId" in (select "id" from "Exercise" where "lessonId" = $1)
    `,
    [lessonId],
  );
  await client.query(`delete from "Exercise" where "lessonId" = $1`, [lessonId]);
  await client.query(`delete from "PronunciationPrompt" where "lessonId" = $1`, [lessonId]);
  await client.query(`delete from "Flashcard" where "lessonId" = $1`, [lessonId]);
  await client.query(`delete from "VocabularyItem" where "lessonId" = $1`, [lessonId]);
  await client.query(`delete from "GrammarTopic" where "lessonId" = $1`, [lessonId]);

  const grammar = seed.sections.grammar;
  await client.query(
    `
      insert into "GrammarTopic" ("id", "lessonId", "title", "explanationHtml", "examplesJson", "orderIndex")
      values ($1, $2, $3, $4, $5::jsonb, 0)
    `,
    [
      randomUUID(),
      lessonId,
      grammar.title,
      (grammar.notes as string[]).map((note) => `<p>${note}</p>`).join(""),
      JSON.stringify(grammar.examples ?? []),
    ],
  );

  for (const [index, item] of seed.vocabulary.entries()) {
    const itemId = randomUUID();

    await client.query(
      `
        insert into "VocabularyItem" (
          "id", "lessonId", "arabic", "transliteration", "dutchMeaning", "notes", "orderIndex"
        )
        values ($1, $2, $3, $4, $5, $6, $7)
      `,
      [itemId, lessonId, item.arabic, item.transliteration ?? null, item.dutchMeaning, item.notes ?? null, index],
    );

    await client.query(
      `
        insert into "Flashcard" (
          "id", "lessonId", "vocabularyItemId", "front", "back", "orderIndex"
        )
        values ($1, $2, $3, $4, $5, $6)
      `,
      [randomUUID(), lessonId, itemId, item.arabic, item.dutchMeaning, index],
    );

    await client.query(
      `
        insert into "PronunciationPrompt" (
          "id", "lessonId", "vocabularyItemId", "expectedText", "transliteration", "dutchMeaning", "orderIndex"
        )
        values ($1, $2, $3, $4, $5, $6, $7)
      `,
      [randomUUID(), lessonId, itemId, item.arabic, item.transliteration ?? null, item.dutchMeaning, index],
    );
  }

  for (const [index, prompt] of seed.pronunciationPrompts.entries()) {
    await client.query(
      `
        insert into "PronunciationPrompt" (
          "id", "lessonId", "expectedText", "transliteration", "dutchMeaning", "orderIndex"
        )
        values ($1, $2, $3, $4, $5, $6)
      `,
      [
        randomUUID(),
        lessonId,
        prompt.expectedText,
        prompt.transliteration ?? null,
        prompt.dutchMeaning ?? null,
        seed.vocabulary.length + index,
      ],
    );
  }

  for (const [exerciseIndex, exercise] of seed.exercises.entries()) {
    const exerciseId = randomUUID();
    await client.query(
      `
        insert into "Exercise" ("id", "lessonId", "type", "prompt", "orderIndex", "metadataJson")
        values ($1, $2, $3, $4, $5, $6::jsonb)
      `,
      [exerciseId, lessonId, exercise.type, exercise.prompt, exerciseIndex, JSON.stringify({ source: seedFileName })],
    );

    for (const [questionIndex, question] of exercise.questions.entries()) {
      await client.query(
        `
          insert into "ExerciseQuestion" (
            "id", "exerciseId", "prompt", "correctAnswerJson", "choicesJson", "explanation", "orderIndex"
          )
          values ($1, $2, $3, $4::jsonb, $5::jsonb, $6, $7)
        `,
        [
          randomUUID(),
          exerciseId,
          question.prompt,
          JSON.stringify({ value: question.correctAnswer }),
          question.choices ? JSON.stringify(question.choices) : null,
          question.explanation ?? null,
          questionIndex,
        ],
      );
    }
  }

  await client.query("commit");
  await client.end();

  console.log(
    `Seeded lesson ${seed.lessonNumber}: ${seed.vocabulary.length} vocabulary items, ${seed.pronunciationPrompts.length + seed.vocabulary.length} pronunciation prompts, ${seed.exercises.length} exercises.`,
  );
}

main().catch(async (error) => {
  console.error(error);
  process.exit(1);
});
