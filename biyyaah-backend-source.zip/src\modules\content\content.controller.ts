import { Controller, Get, Param, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { ContentService } from "./content.service";

@Controller()
export class ContentController {
  constructor(private readonly contentService: ContentService) {}

  @Get("courses")
  getCourses() {
    return this.contentService.getCourses();
  }

  @Get("courses/:slug")
  getCourse(@Param("slug") slug: string) {
    return this.contentService.getCourseBySlug(slug);
  }

  @Get("modules")
  getModules() {
    return this.contentService.getModules();
  }

  @Get("modules/:moduleId")
  getModule(@Param("moduleId") moduleId: string) {
    return this.contentService.getModule(moduleId);
  }

  @Get("lessons/:lessonId")
  getLesson(@Param("lessonId") lessonId: string) {
    return this.contentService.getLesson(lessonId);
  }

  @Get("lessons/:lessonId/sections")
  getLessonSections(@Param("lessonId") lessonId: string) {
    return this.contentService.getLessonSections(lessonId);
  }

  @Get("me/library")
  @UseGuards(BearerAuthGuard)
  getMyLibrary(@CurrentUserId() userId: string) {
    return this.contentService.getUserLibrary(userId);
  }
}
