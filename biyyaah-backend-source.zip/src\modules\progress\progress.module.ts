import { Module } from "@nestjs/common";

import { AuthModule } from "../auth/auth.module";
import { DemoProgressController } from "./demo-progress.controller";
import { ProgressController } from "./progress.controller";
import { ProgressService } from "./progress.service";

@Module({
  imports: [AuthModule],
  controllers: [ProgressController, DemoProgressController],
  providers: [ProgressService],
})
export class ProgressModule {}
