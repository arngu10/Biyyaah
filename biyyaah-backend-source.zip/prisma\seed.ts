import { PrismaClient, LessonSectionType } from "@prisma/client";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const prisma = new PrismaClient();

type LessonSeed = {
  lessonNumber: number;
  variants: string[];
  title: string;
  isExam: boolean;
  lockedByDefault: boolean;
};

type ModuleSeed = {
  moduleNumber: number;
  title: string;
  sourceBook?: string;
  focus?: string;
  lockedByDefault: boolean;
  lessons: LessonSeed[];
};

type CourseSeed = {
  course: {
    slug: string;
    title: string;
    language: string;
  };
  modules: ModuleSeed[];
};

const seedPath = join(__dirname, "seed-data", "lesson-outline.json");
const seed = JSON.parse(readFileSync(seedPath, "utf-8")) as CourseSeed;

async function main() {
  const course = await prisma.course.upsert({
    where: { slug: seed.course.slug },
    update: {
      title: seed.course.title,
      language: seed.course.language,
    },
    create: seed.course,
  });

  for (const moduleSeed of seed.modules) {
    const module = await prisma.module.upsert({
      where: {
        courseId_moduleNumber: {
          courseId: course.id,
          moduleNumber: moduleSeed.moduleNumber,
        },
      },
      update: {
        title: moduleSeed.title,
        sourceBook: moduleSeed.sourceBook,
        focus: moduleSeed.focus,
        lockedByDefault: moduleSeed.lockedByDefault,
      },
      create: {
        courseId: course.id,
        moduleNumber: moduleSeed.moduleNumber,
        title: moduleSeed.title,
        sourceBook: moduleSeed.sourceBook,
        focus: moduleSeed.focus,
        lockedByDefault: moduleSeed.lockedByDefault,
      },
    });

    for (const lessonSeed of moduleSeed.lessons) {
      const lesson = await prisma.lesson.upsert({
        where: {
          moduleId_lessonNumber: {
            moduleId: module.id,
            lessonNumber: lessonSeed.lessonNumber,
          },
        },
        update: {
          title: lessonSeed.title,
          variants: lessonSeed.variants,
          isExam: lessonSeed.isExam,
          lockedByDefault: lessonSeed.lockedByDefault,
        },
        create: {
          moduleId: module.id,
          lessonNumber: lessonSeed.lessonNumber,
          title: lessonSeed.title,
          variants: lessonSeed.variants,
          isExam: lessonSeed.isExam,
          lockedByDefault: lessonSeed.lockedByDefault,
        },
      });

      await ensureEmptySections(lesson.id);
    }
  }

  const lessonCount = seed.modules.reduce((count, module) => count + module.lessons.length, 0);
  console.log(`Seeded ${seed.modules.length} modules and ${lessonCount} lessons.`);
}

async function ensureEmptySections(lessonId: string) {
  const sections = [
    [LessonSectionType.grammar, "Grammar"],
    [LessonSectionType.vocabulary, "Vocabulary"],
    [LessonSectionType.exercises, "Exercises"],
    [LessonSectionType.summary, "Summary"],
    [LessonSectionType.pronunciation, "Pronunciation"],
  ] as const;

  for (const [type, title] of sections) {
    const existing = await prisma.lessonSection.findFirst({
      where: { lessonId, type },
    });

    if (!existing) {
      await prisma.lessonSection.create({
        data: {
          lessonId,
          type,
          title,
          orderIndex: sections.findIndex(([sectionType]) => sectionType === type),
          contentJson: {},
        },
      });
    }
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
