import { IsOptional, IsString, MaxLength, MinLength } from "class-validator";

export class GenerateReferenceAudioDto {
  @IsString()
  @MinLength(1)
  @MaxLength(4096)
  text!: string;

  @IsOptional()
  @IsString()
  languageCode?: string;
}

