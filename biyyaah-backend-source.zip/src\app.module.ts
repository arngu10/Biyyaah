import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";

import { AudioModule } from "./modules/audio/audio.module";
import { AuthModule } from "./modules/auth/auth.module";
import { BillingModule } from "./modules/billing/billing.module";
import { ContentModule } from "./modules/content/content.module";
import { ExercisesModule } from "./modules/exercises/exercises.module";
import { FlashcardsModule } from "./modules/flashcards/flashcards.module";
import { ProfilesModule } from "./modules/profiles/profiles.module";
import { ProgressModule } from "./modules/progress/progress.module";
import { StorageModule } from "./modules/storage/storage.module";
import { PrismaModule } from "./prisma/prisma.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    StorageModule,
    AuthModule,
    ProfilesModule,
    ContentModule,
    ProgressModule,
    ExercisesModule,
    FlashcardsModule,
    AudioModule,
    BillingModule,
  ],
})
export class AppModule {}
