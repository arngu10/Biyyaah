from pathlib import Path

from PIL import Image, ImageDraw

SOURCE_DIR = Path(r"C:\Users\tima_\Documents\Codex\Biyyaah\content\book-1-pages")
OUTPUT = Path(r"C:\Users\tima_\Documents\Codex\Biyyaah\content\book-1-pages-contact.png")

images = sorted(SOURCE_DIR.glob("book-1-page-*.png"))
thumb_w = 420
thumb_h = 594
gap = 24
cols = 4
rows = (len(images) + cols - 1) // cols

sheet = Image.new("RGB", (cols * thumb_w + (cols + 1) * gap, rows * (thumb_h + 42) + gap), "white")
draw = ImageDraw.Draw(sheet)

for index, path in enumerate(images):
    image = Image.open(path).convert("RGB")
    image.thumbnail((thumb_w, thumb_h))
    x = gap + (index % cols) * (thumb_w + gap)
    y = gap + (index // cols) * (thumb_h + 42)
    sheet.paste(image, (x, y))
    draw.text((x, y + thumb_h + 8), path.stem.replace("book-1-page-", "page "), fill="black")

sheet.save(OUTPUT)
print(OUTPUT)
