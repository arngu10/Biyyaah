import { Injectable, NotFoundException } from "@nestjs/common";

import { PrismaService } from "../../prisma/prisma.service";

@Injectable()
export class ContentService {
  constructor(private readonly prisma: PrismaService) {}

  getCourses() {
    return this.prisma.course.findMany({
      orderBy: { title: "asc" },
      include: {
        modules: {
          orderBy: { moduleNumber: "asc" },
          select: {
            id: true,
            moduleNumber: true,
            title: true,
            sourceBook: true,
            focus: true,
            lockedByDefault: true,
          },
        },
      },
    });
  }

  async getCourseBySlug(slug: string) {
    const course = await this.prisma.course.findUnique({
      where: { slug },
      include: {
        modules: {
          orderBy: { moduleNumber: "asc" },
          include: {
            lessons: {
              orderBy: { lessonNumber: "asc" },
              select: {
                id: true,
                lessonNumber: true,
                title: true,
                variants: true,
                isExam: true,
                lockedByDefault: true,
              },
            },
          },
        },
      },
    });

    if (!course) throw new NotFoundException("Course not found");
    return course;
  }

  getModules() {
    return this.prisma.module.findMany({
      orderBy: [{ courseId: "asc" }, { moduleNumber: "asc" }],
      include: {
        lessons: {
          orderBy: { lessonNumber: "asc" },
          select: {
            id: true,
            lessonNumber: true,
            title: true,
            variants: true,
            isExam: true,
            lockedByDefault: true,
          },
        },
      },
    });
  }

  async getModule(moduleId: string) {
    const module = await this.prisma.module.findUnique({
      where: { id: moduleId },
      include: {
        lessons: {
          orderBy: { lessonNumber: "asc" },
        },
      },
    });

    if (!module) throw new NotFoundException("Module not found");
    return module;
  }

  async getLesson(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      include: {
        module: true,
        sections: {
          orderBy: { orderIndex: "asc" },
        },
        grammarTopics: {
          orderBy: { orderIndex: "asc" },
        },
        vocabularyItems: {
          orderBy: { orderIndex: "asc" },
          include: { audioAsset: true },
        },
        exercises: {
          orderBy: { orderIndex: "asc" },
          include: {
            questions: {
              orderBy: { orderIndex: "asc" },
            },
          },
        },
        pronunciationPrompts: {
          orderBy: { orderIndex: "asc" },
          include: { referenceAudioAsset: true },
        },
      },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");
    return lesson;
  }

  async getLessonSections(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { id: true },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");

    return this.prisma.lessonSection.findMany({
      where: { lessonId },
      orderBy: { orderIndex: "asc" },
    });
  }

  async getUserLibrary(userId: string) {
    const modules = await this.prisma.module.findMany({
      orderBy: { moduleNumber: "asc" },
      include: {
        lessons: {
          orderBy: { lessonNumber: "asc" },
          include: {
            progress: {
              where: { userId },
            },
            vocabularyItems: {
              orderBy: { orderIndex: "asc" },
              include: {
                audioAsset: true,
                flashcards: {
                  include: {
                    reviews: {
                      where: { userId },
                      orderBy: { reviewedAt: "desc" },
                      take: 1,
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    const lessonGroups = modules.map((module) => ({
      id: module.id,
      moduleNumber: module.moduleNumber,
      title: module.title,
      sourceBook: module.sourceBook,
      lessons: module.lessons.map((lesson) => {
        const words = lesson.vocabularyItems.map((word) => {
          const latestReview = word.flashcards[0]?.reviews[0];

          return {
            id: word.id,
            arabic: word.arabic,
            transliteration: word.transliteration,
            dutchMeaning: word.dutchMeaning,
            notes: word.notes,
            audioAsset: word.audioAsset,
            status: latestReview ? "geleerd" : "nieuw",
            lastReviewedAt: latestReview?.reviewedAt ?? null,
            nextReviewAt: latestReview?.nextReviewAt ?? null,
          };
        });

        return {
          id: lesson.id,
          lessonNumber: lesson.lessonNumber,
          title: lesson.title,
          status: lesson.progress[0]?.status ?? "locked",
          wordCount: words.length,
          learnedWordCount: words.filter((word) => word.status === "geleerd").length,
          words,
        };
      }),
    }));

    return {
      modules: lessonGroups,
      totals: {
        lessons: lessonGroups.reduce((total, module) => total + module.lessons.length, 0),
        words: lessonGroups.reduce(
          (moduleTotal, module) =>
            moduleTotal + module.lessons.reduce((lessonTotal, lesson) => lessonTotal + lesson.wordCount, 0),
          0,
        ),
        learnedWords: lessonGroups.reduce(
          (moduleTotal, module) =>
            moduleTotal + module.lessons.reduce((lessonTotal, lesson) => lessonTotal + lesson.learnedWordCount, 0),
          0,
        ),
      },
    };
  }
}
