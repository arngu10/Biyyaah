import { Injectable, NotFoundException } from "@nestjs/common";
import { Prisma } from "@prisma/client";

import { PrismaService } from "../../prisma/prisma.service";
import { SubmitExerciseAttemptDto } from "./dto/submit-exercise-attempt.dto";

@Injectable()
export class ExercisesService {
  constructor(private readonly prisma: PrismaService) {}

  async getLessonExercises(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { id: true },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");

    return this.prisma.exercise.findMany({
      where: { lessonId },
      orderBy: { orderIndex: "asc" },
      include: {
        questions: {
          orderBy: { orderIndex: "asc" },
        },
      },
    });
  }

  async submitAttempt(userId: string, exerciseId: string, body: SubmitExerciseAttemptDto) {
    const exercise = await this.prisma.exercise.findUnique({
      where: { id: exerciseId },
      include: {
        questions: {
          orderBy: { orderIndex: "asc" },
        },
      },
    });

    if (!exercise) throw new NotFoundException("Exercise not found");

    const score = this.scoreAttempt(exercise.questions, body);

    return this.prisma.exerciseAttempt.create({
      data: {
        userId,
        exerciseId,
        lessonId: exercise.lessonId,
        answerJson: body.answer as Prisma.InputJsonValue,
        score: score.score,
        isCorrect: score.isCorrect,
      },
    });
  }

  private scoreAttempt(
    questions: Array<{ id: string; correctAnswerJson: unknown }>,
    body: SubmitExerciseAttemptDto,
  ) {
    const question = body.questionId ? questions.find((item) => item.id === body.questionId) : questions[0];
    if (!question) return { score: null, isCorrect: null };

    const expected = JSON.stringify(question.correctAnswerJson);
    const actual = JSON.stringify(body.answer);
    const isCorrect = expected === actual;

    return {
      score: isCorrect ? 1 : 0,
      isCorrect,
    };
  }
}
