# Biyyaah Backend Blueprint

## What OCR Means

OCR stands for optical character recognition. It is the process of taking text that is trapped inside an image or scanned PDF page and converting it into editable text.

In this project, the Medina book PDFs appear to be scanned/image PDFs, so normal PDF extraction cannot read the lesson text. OCR is how we turn those scanned pages into structured content that the app can use for grammar, vocabulary, exercises, summaries, and pronunciation prompts.

## Product Understanding

Biyyaah is a Dutch-market Arabic learning platform based on the Medina curriculum. A module is one complete book or curriculum part. Lessons unlock in order. Each lesson includes theory/grammar, vocabulary, exercises, summary, flashcards, and pronunciation practice.

The learner experience is:

1. Create account or log in.
2. Complete onboarding preferences.
3. Start Module 1.
4. Progress lesson by lesson.
5. Study theory, vocabulary, exercises, summaries, and flashcards.
6. Listen to reference pronunciation audio.
7. Record their own pronunciation.
8. Receive AI scoring and feedback.
9. Build streaks, unlock certificates, and progress through modules.

## Curriculum Structure

Source outline: `Lessons_ modules.pdf`

Generated seed file: `lesson_outline.seed.json`

Current structure:

- Module 1: De Basis, Madinah Boek 1, 24 lessons
- Module 2: Verdieping, Madinah Boek 2, 32 lessons
- Module 3: Structuur, Madinah Boek 3 - Deel 1, 16 lessons
- Module 4: Beheersing, Madinah Boek 3 - Deel 2, 20 lessons

Total: 92 lessons.

## Recommended Stack

- Backend: Node.js with NestJS
- Database: PostgreSQL
- ORM: Prisma
- Auth: email/password plus Google OAuth
- Payments: Stripe monthly/yearly subscriptions
- Storage: S3, Cloudflare R2, or Supabase Storage
- AI pronunciation: speech-to-text plus scoring rubric
- Content pipeline: JSON/CSV seed files generated from OCR and manual review

NestJS is recommended because the app will grow into modules: auth, content, progress, billing, audio, pronunciation, and later admin.

## Core Data Model

### Users

`users`

- id
- email
- passwordHash
- displayName
- role: learner
- emailVerifiedAt
- createdAt
- updatedAt

`auth_accounts`

- id
- userId
- provider: google
- providerAccountId
- createdAt

`user_profiles`

- id
- userId
- goal
- startingLevel
- nativeLanguage
- dailyLearningMinutes
- preferredStudyTime
- remindersEnabled
- studyGoalsEnabled
- audioModeEnabled
- darkModeEnabled
- createdAt
- updatedAt

### Curriculum

`courses`

- id
- slug
- title
- language
- createdAt
- updatedAt

`modules`

- id
- courseId
- moduleNumber
- title
- sourceBook
- focus
- lockedByDefault
- createdAt
- updatedAt

`lessons`

- id
- moduleId
- lessonNumber
- title
- variants
- isExam
- lockedByDefault
- estimatedMinutes
- createdAt
- updatedAt

`lesson_sections`

- id
- lessonId
- type: grammar | vocabulary | exercises | summary | pronunciation
- title
- orderIndex
- contentJson
- createdAt
- updatedAt

### Vocabulary And Grammar

`grammar_topics`

- id
- lessonId
- title
- explanationHtml
- examplesJson
- orderIndex

`vocabulary_items`

- id
- lessonId
- arabic
- transliteration
- dutchMeaning
- notes
- orderIndex
- audioAssetId

### Exercises

`exercises`

- id
- lessonId
- type: multiple_choice | fill_blank | matching | translation | written
- prompt
- orderIndex
- metadataJson

`exercise_questions`

- id
- exerciseId
- prompt
- correctAnswerJson
- choicesJson
- explanation
- orderIndex

`exercise_attempts`

- id
- userId
- exerciseId
- lessonId
- answerJson
- score
- isCorrect
- submittedAt

### Flashcards

`flashcards`

- id
- lessonId
- vocabularyItemId
- front
- back
- audioAssetId
- orderIndex

`flashcard_reviews`

- id
- userId
- flashcardId
- rating: again | hard | good | easy
- nextReviewAt
- reviewedAt

### Progress

`lesson_progress`

- id
- userId
- lessonId
- status: locked | unlocked | in_progress | completed
- grammarCompletedAt
- vocabularyCompletedAt
- exercisesCompletedAt
- summaryCompletedAt
- pronunciationCompletedAt
- completedAt
- updatedAt

`module_progress`

- id
- userId
- moduleId
- status: locked | unlocked | in_progress | completed
- completedLessonsCount
- completedAt
- updatedAt

`streaks`

- id
- userId
- currentStreakDays
- longestStreakDays
- lastActivityDate
- updatedAt

`certificates`

- id
- userId
- moduleId
- certificateUrl
- issuedAt

### Audio And Pronunciation

`audio_assets`

- id
- sourceType: human | ai_generated
- languageCode
- voiceName
- text
- fileUrl
- durationMs
- reviewedAt
- createdAt

`pronunciation_prompts`

- id
- lessonId
- vocabularyItemId
- expectedText
- transliteration
- dutchMeaning
- referenceAudioAssetId
- orderIndex

`user_recordings`

- id
- userId
- pronunciationPromptId
- fileUrl
- durationMs
- createdAt

`pronunciation_scores`

- id
- userRecordingId
- userId
- pronunciationPromptId
- overallScore
- accuracyScore
- fluencyScore
- completionScore
- feedbackJson
- createdAt

### Billing

`subscriptions`

- id
- userId
- stripeCustomerId
- stripeSubscriptionId
- plan: monthly | yearly
- status
- currentPeriodStart
- currentPeriodEnd
- cancelAtPeriodEnd
- createdAt
- updatedAt

## Unlock Logic

Default rules:

- Module 1 is unlocked for new users.
- First lesson in Module 1 is unlocked.
- Lessons unlock sequentially after the previous lesson is completed.
- A module is completed when all non-exam lessons and its exam are completed.
- The next module unlocks when the previous module is completed.
- Subscription rules can override access for paid modules or advanced lessons.

## API Routes

### Auth

- `POST /auth/register`
- `POST /auth/login`
- `GET /auth/google`
- `GET /auth/google/callback`
- `POST /auth/logout`
- `GET /me`

### Onboarding

- `GET /me/profile`
- `PATCH /me/profile`
- `POST /onboarding/complete`

### Curriculum

- `GET /courses`
- `GET /courses/:slug`
- `GET /modules`
- `GET /modules/:moduleId`
- `GET /lessons/:lessonId`
- `GET /lessons/:lessonId/sections`

### Progress

- `GET /me/progress`
- `GET /me/modules/:moduleId/progress`
- `POST /lessons/:lessonId/start`
- `POST /lessons/:lessonId/sections/:sectionId/complete`
- `POST /lessons/:lessonId/complete`

### Exercises

- `GET /lessons/:lessonId/exercises`
- `POST /exercises/:exerciseId/attempts`

### Flashcards

- `GET /lessons/:lessonId/flashcards`
- `POST /flashcards/:flashcardId/review`
- `GET /me/flashcards/re due`

### Audio

- `GET /lessons/:lessonId/pronunciation-prompts`
- `POST /pronunciation-prompts/:promptId/recordings`
- `POST /recordings/:recordingId/score`

### Billing

- `POST /billing/checkout`
- `POST /billing/portal`
- `POST /webhooks/stripe`
- `GET /me/subscription`

## Lesson Seed Format

The final seed format should look like this:

```json
{
  "moduleNumber": 1,
  "lessonNumber": 1,
  "title": "Mannelijke aanwijzende voornaamwoorden",
  "isExam": false,
  "grammar": [
    {
      "title": "Main concept",
      "explanation": "Dutch explanation",
      "examples": [
        {
          "arabic": "هٰذَا بَيْتٌ",
          "transliteration": "haadhaa baytun",
          "dutch": "Dit is een huis."
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "arabic": "بَيْتٌ",
      "transliteration": "baytun",
      "dutch": "huis",
      "notes": ""
    }
  ],
  "exercises": [
    {
      "type": "multiple_choice",
      "prompt": "Choose the correct meaning.",
      "questions": []
    }
  ],
  "summary": "Short Dutch lesson summary.",
  "pronunciationPrompts": [
    {
      "expectedText": "بَيْتٌ",
      "transliteration": "baytun",
      "dutchMeaning": "huis"
    }
  ]
}
```

## Content Pipeline

1. Use `lesson_outline.seed.json` as the official lesson skeleton.
2. OCR the Medina PDFs.
3. Split OCR output by book, page, and lesson.
4. Extract grammar explanations, vocabulary, exercises, examples, and summaries.
5. Generate draft lesson JSON.
6. Manually review Arabic text and Dutch explanations.
7. Generate or record reference audio.
8. Seed reviewed content into the database.

## Audio Pipeline

Initial launch approach:

1. Generate reference audio for all vocabulary and pronunciation prompts.
2. Store generated files in object storage.
3. Link audio assets to vocabulary and prompts.
4. Add a review flag so human-reviewed audio can replace generated audio later.

Recommended quality approach:

- Use AI-generated audio to move quickly.
- Human-review Book 1 before launch.
- Replace important prompts with human-recorded audio over time.

## AI Pronunciation Scoring

Scoring flow:

1. User records audio in the frontend.
2. Backend uploads audio to storage.
3. Backend sends audio plus expected Arabic text to the scoring pipeline.
4. Pipeline returns:
   - overall score
   - accuracy score
   - fluency score
   - completion score
   - user-friendly Dutch feedback
5. Backend saves the score.
6. Frontend shows feedback and lets the learner try again.

## Implementation Phases

### Phase 1: Backend Foundation

- NestJS app
- PostgreSQL
- Prisma schema
- Auth with email/password
- User profile and onboarding preferences
- Course/module/lesson seed import from `lesson_outline.seed.json`

### Phase 2: Learner Progress

- Module and lesson APIs
- Sequential unlock logic
- Section completion
- Lesson completion
- Streak tracking

### Phase 3: Lesson Content

- Final lesson JSON format
- Module 1 content import
- Vocabulary
- Grammar
- Exercises
- Summaries
- Flashcards

### Phase 4: Audio And Pronunciation

- Audio asset storage
- Reference audio generation/storage
- User recording upload
- AI scoring endpoint
- Pronunciation score history

### Phase 5: Billing

- Stripe products/prices
- Monthly/yearly checkout
- Stripe customer portal
- Stripe webhooks
- Subscription access rules

### Phase 6: Admin Later

- Content editor
- Audio review workflow
- User management
- Progress analytics

## Immediate Next Step

Build the backend foundation and content seed importer first. In parallel, start OCR on Book 1 so Module 1 can become the pilot content module.
