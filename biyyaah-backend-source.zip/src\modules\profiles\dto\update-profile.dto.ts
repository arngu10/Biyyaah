import { IsBoolean, IsInt, IsOptional, IsString, Max, Min } from "class-validator";

export class UpdateProfileDto {
  @IsOptional()
  @IsString()
  goal?: string;

  @IsOptional()
  @IsString()
  startingLevel?: string;

  @IsOptional()
  @IsString()
  nativeLanguage?: string;

  @IsOptional()
  @IsInt()
  @Min(5)
  @Max(240)
  dailyLearningMinutes?: number;

  @IsOptional()
  @IsString()
  preferredStudyTime?: string;

  @IsOptional()
  @IsBoolean()
  remindersEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  studyGoalsEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  audioModeEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  darkModeEnabled?: boolean;
}

