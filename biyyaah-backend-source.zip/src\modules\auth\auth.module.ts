import { Module } from "@nestjs/common";

import { AuthController } from "./auth.controller";
import { BearerAuthGuard } from "./bearer-auth.guard";
import { AuthTokenService } from "./auth-token.service";
import { AuthService } from "./auth.service";

@Module({
  controllers: [AuthController],
  providers: [AuthService, AuthTokenService, BearerAuthGuard],
  exports: [AuthService, AuthTokenService, BearerAuthGuard],
})
export class AuthModule {}
