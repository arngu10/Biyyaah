import { Controller, Get, Post } from "@nestjs/common";

import { BillingService } from "./billing.service";

@Controller()
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  @Post("billing/checkout")
  createCheckout() {
    return this.billingService.createCheckout("demo-user");
  }

  @Post("billing/portal")
  createPortal() {
    return this.billingService.createPortal("demo-user");
  }

  @Get("me/subscription")
  getSubscription() {
    return this.billingService.getSubscription("demo-user");
  }
}
