import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { AudioService } from "./audio.service";
import { CreateRecordingDto } from "./dto/create-recording.dto";
import { CreateRecordingUploadDto } from "./dto/create-recording-upload.dto";
import { GenerateReferenceAudioDto } from "./dto/generate-reference-audio.dto";
import { ScoreRecordingDto } from "./dto/score-recording.dto";

@Controller()
@UseGuards(BearerAuthGuard)
export class AudioController {
  constructor(private readonly audioService: AudioService) {}

  @Get("lessons/:lessonId/pronunciation-prompts")
  getPronunciationPrompts(@Param("lessonId") lessonId: string) {
    return this.audioService.getPronunciationPrompts(lessonId);
  }

  @Post("audio/reference")
  generateReferenceAudio(@Body() body: GenerateReferenceAudioDto) {
    return this.audioService.generateReferenceAudio(body);
  }

  @Post("pronunciation-prompts/:promptId/reference-audio")
  generatePromptReferenceAudio(@Param("promptId") promptId: string) {
    return this.audioService.generatePromptReferenceAudio(promptId);
  }

  @Post("pronunciation-prompts/:promptId/recordings/upload-url")
  createRecordingUpload(
    @CurrentUserId() userId: string,
    @Param("promptId") promptId: string,
    @Body() body: CreateRecordingUploadDto,
  ) {
    return this.audioService.createRecordingUpload(userId, promptId, body);
  }

  @Post("pronunciation-prompts/:promptId/recordings")
  createRecording(
    @CurrentUserId() userId: string,
    @Param("promptId") promptId: string,
    @Body() body: CreateRecordingDto,
  ) {
    return this.audioService.createRecording(userId, promptId, body);
  }

  @Post("recordings/:recordingId/score")
  scoreRecording(
    @CurrentUserId() userId: string,
    @Param("recordingId") recordingId: string,
    @Body() body: ScoreRecordingDto,
  ) {
    return this.audioService.scoreRecording(userId, recordingId, body);
  }
}
