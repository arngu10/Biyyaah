from pathlib import Path

from pypdf import PdfReader

files = [
    Path(r"C:\Users\tima_\Downloads\Medina Boek 1 Nederlands (1).pdf"),
    Path(r"C:\Users\tima_\Downloads\Medina Boek 2 Nederlands.pdf"),
    Path(r"C:\Users\tima_\Downloads\Medina Boek 3 Nederlands.pdf"),
]

for file in files:
    reader = PdfReader(file)
    print(f"=== {file.name} | {len(reader.pages)} pages ===")
    for index in range(min(8, len(reader.pages))):
        page = reader.pages[index]
        images = list(page.images)
        print(f"page {index + 1}: {len(images)} images")
        for image in images[:3]:
            print(f"  {image.name} {len(image.data)} bytes")
