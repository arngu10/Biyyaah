import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { SubmitExerciseAttemptDto } from "./dto/submit-exercise-attempt.dto";
import { ExercisesService } from "./exercises.service";

@Controller()
@UseGuards(BearerAuthGuard)
export class ExercisesController {
  constructor(private readonly exercisesService: ExercisesService) {}

  @Get("lessons/:lessonId/exercises")
  getLessonExercises(@Param("lessonId") lessonId: string) {
    return this.exercisesService.getLessonExercises(lessonId);
  }

  @Post("exercises/:exerciseId/attempts")
  submitAttempt(
    @CurrentUserId() userId: string,
    @Param("exerciseId") exerciseId: string,
    @Body() body: SubmitExerciseAttemptDto,
  ) {
    return this.exercisesService.submitAttempt(userId, exerciseId, body);
  }
}

