import { Injectable } from "@nestjs/common";

@Injectable()
export class BillingService {
  createCheckout(userId: string) {
    return {
      userId,
      message: "Stripe Checkout will be created here for monthly/yearly plans.",
    };
  }

  createPortal(userId: string) {
    return {
      userId,
      message: "Stripe billing portal session will be created here.",
    };
  }

  getSubscription(userId: string) {
    return {
      userId,
      status: "not_configured",
    };
  }
}

