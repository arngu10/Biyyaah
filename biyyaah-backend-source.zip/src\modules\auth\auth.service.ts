import { ConflictException, Injectable, UnauthorizedException } from "@nestjs/common";
import * as bcrypt from "bcrypt";

import { PrismaService } from "../../prisma/prisma.service";
import { AuthTokenService } from "./auth-token.service";

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tokens: AuthTokenService,
  ) {}

  async register(body: { email: string; password: string; displayName?: string }) {
    const email = body.email.trim().toLowerCase();
    const existing = await this.prisma.user.findUnique({ where: { email } });

    if (existing) {
      throw new ConflictException("An account with this email already exists");
    }

    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await this.prisma.user.create({
      data: {
        email,
        passwordHash,
        displayName: body.displayName,
        profile: {
          create: {},
        },
      },
      select: this.safeUserSelect(),
    });

    return {
      user,
      accessToken: this.tokens.sign({ sub: user.id, email: user.email }),
    };
  }

  async login(body: { email: string; password: string }) {
    const email = body.email.trim().toLowerCase();
    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user?.passwordHash) {
      throw new UnauthorizedException("Invalid email or password");
    }

    const validPassword = await bcrypt.compare(body.password, user.passwordHash);
    if (!validPassword) {
      throw new UnauthorizedException("Invalid email or password");
    }

    return {
      user: this.toSafeUser(user),
      accessToken: this.tokens.sign({ sub: user.id, email: user.email }),
    };
  }

  async me(authorization?: string) {
    const payload = this.tokens.verifyAuthorizationHeader(authorization);
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
      select: this.safeUserSelect(),
    });

    if (!user) throw new UnauthorizedException("User not found");
    return user;
  }

  getUserIdFromAuthorization(authorization?: string) {
    return this.tokens.verifyAuthorizationHeader(authorization).sub;
  }

  private safeUserSelect() {
    return {
      id: true,
      email: true,
      displayName: true,
      role: true,
      emailVerifiedAt: true,
      createdAt: true,
      updatedAt: true,
      profile: true,
    };
  }

  private toSafeUser(user: {
    id: string;
    email: string;
    displayName: string | null;
    role: "learner";
    emailVerifiedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      role: user.role,
      emailVerifiedAt: user.emailVerifiedAt,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };
  }
}
