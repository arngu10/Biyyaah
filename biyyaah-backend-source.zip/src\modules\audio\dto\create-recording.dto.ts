import { IsInt, IsOptional, IsString, IsUrl, Max, Min } from "class-validator";

export class CreateRecordingDto {
  @IsUrl({ require_tld: false })
  fileUrl!: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(120000)
  durationMs?: number;
}

