import { Injectable, UnauthorizedException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { createHmac, timingSafeEqual } from "node:crypto";

type TokenPayload = {
  sub: string;
  email: string;
  iat: number;
  exp: number;
};

@Injectable()
export class AuthTokenService {
  constructor(private readonly config: ConfigService) {}

  sign(payload: { sub: string; email: string }) {
    const now = Math.floor(Date.now() / 1000);
    const tokenPayload: TokenPayload = {
      ...payload,
      iat: now,
      exp: now + 60 * 60 * 24 * 30,
    };

    const header = this.encode({ alg: "HS256", typ: "JWT" });
    const body = this.encode(tokenPayload);
    const signature = this.signPart(`${header}.${body}`);

    return `${header}.${body}.${signature}`;
  }

  verifyAuthorizationHeader(authorization?: string) {
    if (!authorization?.startsWith("Bearer ")) {
      throw new UnauthorizedException("Missing bearer token");
    }

    return this.verify(authorization.slice("Bearer ".length));
  }

  verify(token: string): TokenPayload {
    const [header, body, signature] = token.split(".");
    if (!header || !body || !signature) {
      throw new UnauthorizedException("Invalid token");
    }

    const expected = this.signPart(`${header}.${body}`);
    const actualBuffer = Buffer.from(signature);
    const expectedBuffer = Buffer.from(expected);

    if (actualBuffer.length !== expectedBuffer.length || !timingSafeEqual(actualBuffer, expectedBuffer)) {
      throw new UnauthorizedException("Invalid token signature");
    }

    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf-8")) as TokenPayload;
    if (payload.exp < Math.floor(Date.now() / 1000)) {
      throw new UnauthorizedException("Token expired");
    }

    return payload;
  }

  private encode(value: unknown) {
    return Buffer.from(JSON.stringify(value)).toString("base64url");
  }

  private signPart(value: string) {
    return createHmac("sha256", this.secret()).update(value).digest("base64url");
  }

  private secret() {
    return this.config.get<string>("JWT_SECRET") ?? "dev-only-change-me";
  }
}

