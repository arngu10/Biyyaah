import { IsIn, IsOptional, IsString, MaxLength } from "class-validator";

const audioContentTypes = ["audio/webm", "audio/wav", "audio/mpeg", "audio/mp4", "audio/x-m4a"] as const;

export class CreateRecordingUploadDto {
  @IsIn(audioContentTypes)
  contentType!: (typeof audioContentTypes)[number];

  @IsOptional()
  @IsString()
  @MaxLength(120)
  fileName?: string;
}

