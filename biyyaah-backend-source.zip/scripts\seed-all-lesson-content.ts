import { readdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { join } from "node:path";

const seedDir = join(__dirname, "..", "prisma", "seed-data");
const seedFiles = readdirSync(seedDir)
  .filter((file) => /^lesson-\d+-content\.json$/.test(file))
  .sort((left, right) => {
    const leftNumber = Number(left.match(/^lesson-(\d+)-content\.json$/)?.[1] ?? 0);
    const rightNumber = Number(right.match(/^lesson-(\d+)-content\.json$/)?.[1] ?? 0);
    return leftNumber - rightNumber;
  });

for (const seedFile of seedFiles) {
  console.log(`Seeding ${seedFile}`);
  const tsxCli = join(__dirname, "..", "..", "..", "node_modules", "tsx", "dist", "cli.cjs");
  const result = spawnSync(process.execPath, [tsxCli, "scripts/seed-lesson-content-sql.ts", seedFile], {
    cwd: join(__dirname, ".."),
    stdio: "inherit",
    shell: false,
  });

  if (result.error) {
    console.error(result.error);
  }

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

console.log(`Seeded ${seedFiles.length} lesson content files.`);
