import { IsOptional, IsString } from "class-validator";

export class ScoreRecordingDto {
  @IsOptional()
  @IsString()
  transcript?: string;
}

