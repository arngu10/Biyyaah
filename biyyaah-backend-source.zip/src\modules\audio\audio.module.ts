import { Module } from "@nestjs/common";

import { AuthModule } from "../auth/auth.module";
import { AudioController } from "./audio.controller";
import { AudioService } from "./audio.service";
import { OpenAiPronunciationScorer } from "./openai-pronunciation.scorer";
import { PronunciationScorer } from "./pronunciation-scorer";
import { ReferenceAudioService } from "./reference-audio.service";

@Module({
  imports: [AuthModule],
  controllers: [AudioController],
  providers: [
    AudioService,
    ReferenceAudioService,
    {
      provide: PronunciationScorer,
      useClass: OpenAiPronunciationScorer,
    },
  ],
})
export class AudioModule {}
