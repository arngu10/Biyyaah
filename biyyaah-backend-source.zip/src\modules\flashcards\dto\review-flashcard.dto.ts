import { IsEnum, IsOptional, IsString } from "class-validator";

export enum FlashcardReviewRatingDto {
  again = "again",
  hard = "hard",
  good = "good",
  easy = "easy",
}

export class ReviewFlashcardDto {
  @IsEnum(FlashcardReviewRatingDto)
  rating!: FlashcardReviewRatingDto;

  @IsOptional()
  @IsString()
  clientReviewedAt?: string;
}

