import { IsObject, IsOptional, IsString } from "class-validator";

export class SubmitExerciseAttemptDto {
  @IsObject()
  answer!: Record<string, unknown>;

  @IsOptional()
  @IsString()
  questionId?: string;
}

