import { Body, Controller, Get, Patch, Post, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { UpdateProfileDto } from "./dto/update-profile.dto";
import { ProfilesService } from "./profiles.service";

@Controller()
@UseGuards(BearerAuthGuard)
export class ProfilesController {
  constructor(private readonly profilesService: ProfilesService) {}

  @Get("me/profile")
  getProfile(@CurrentUserId() userId: string) {
    return this.profilesService.getProfile(userId);
  }

  @Patch("me/profile")
  updateProfile(@CurrentUserId() userId: string, @Body() body: UpdateProfileDto) {
    return this.profilesService.updateProfile(userId, body);
  }

  @Post("onboarding/complete")
  completeOnboarding(@CurrentUserId() userId: string, @Body() body: UpdateProfileDto) {
    return this.profilesService.completeOnboarding(userId, body);
  }
}
