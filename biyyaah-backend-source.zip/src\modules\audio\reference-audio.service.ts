import { Injectable, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AudioSourceType } from "@prisma/client";
import OpenAI from "openai";

import { PrismaService } from "../../prisma/prisma.service";
import { SupabaseStorageService } from "../storage/supabase-storage.service";

@Injectable()
export class ReferenceAudioService {
  private readonly client?: OpenAI;
  private readonly model: string;
  private readonly voice: string;

  constructor(
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly storage: SupabaseStorageService,
  ) {
    const apiKey = this.config.get<string>("OPENAI_API_KEY");
    this.model = this.config.get<string>("OPENAI_TTS_MODEL") ?? "gpt-4o-mini-tts";
    this.voice = this.config.get<string>("OPENAI_TTS_VOICE") ?? "coral";

    if (apiKey) {
      this.client = new OpenAI({ apiKey });
    }
  }

  async generateForText(input: {
    text: string;
    languageCode?: string;
    pathPrefix?: string;
  }) {
    const client = this.requireClient();
    const languageCode = input.languageCode ?? "ar";
    const path = `${input.pathPrefix ?? "reference"}/${Date.now()}-${this.slugify(input.text)}.mp3`;

    const speech = await client.audio.speech.create({
      model: this.model,
      voice: this.voice,
      input: input.text,
      instructions: "Pronounce the Arabic clearly, slowly, and naturally for a beginner learner.",
      response_format: "mp3",
    });

    const uploaded = await this.storage.upload(path, Buffer.from(await speech.arrayBuffer()), "audio/mpeg");

    return this.prisma.audioAsset.create({
      data: {
        sourceType: AudioSourceType.ai_generated,
        languageCode,
        voiceName: this.voice,
        text: input.text,
        fileUrl: uploaded.fileUrl,
      },
    });
  }

  private slugify(value: string) {
    const ascii = value
      .normalize("NFKD")
      .replace(/[^\w\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .toLowerCase();

    return ascii || "arabic-audio";
  }

  private requireClient() {
    if (!this.client) {
      throw new ServiceUnavailableException("OpenAI is not configured");
    }

    return this.client;
  }
}
