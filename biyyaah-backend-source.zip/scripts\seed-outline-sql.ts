import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

type LessonSeed = {
  lessonNumber: number;
  variants: string[];
  title: string;
  isExam: boolean;
  lockedByDefault: boolean;
};

type ModuleSeed = {
  moduleNumber: number;
  title: string;
  sourceBook?: string;
  focus?: string;
  lockedByDefault: boolean;
  lessons: LessonSeed[];
};

type CourseSeed = {
  course: {
    slug: string;
    title: string;
    language: string;
  };
  modules: ModuleSeed[];
};

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required");

  const seedPath = join(__dirname, "..", "prisma", "seed-data", "lesson-outline.json");
  const seed = JSON.parse(readFileSync(seedPath, "utf-8")) as CourseSeed;
  const client = new pg.Client({
    connectionString,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  await client.query("begin");

  const courseResult = await client.query<{ id: string }>(
    `
      insert into "Course" ("id", "slug", "title", "language", "createdAt", "updatedAt")
      values ($1, $2, $3, $4, now(), now())
      on conflict ("slug")
      do update set "title" = excluded."title", "language" = excluded."language", "updatedAt" = now()
      returning "id"
    `,
    [randomUUID(), seed.course.slug, seed.course.title, seed.course.language],
  );
  const courseId = courseResult.rows[0].id;

  let lessonCount = 0;

  for (const moduleSeed of seed.modules) {
    const moduleResult = await client.query<{ id: string }>(
      `
        insert into "Module" (
          "id", "courseId", "moduleNumber", "title", "sourceBook", "focus", "lockedByDefault", "createdAt", "updatedAt"
        )
        values ($1, $2, $3, $4, $5, $6, $7, now(), now())
        on conflict ("courseId", "moduleNumber")
        do update set
          "title" = excluded."title",
          "sourceBook" = excluded."sourceBook",
          "focus" = excluded."focus",
          "lockedByDefault" = excluded."lockedByDefault",
          "updatedAt" = now()
        returning "id"
      `,
      [
        randomUUID(),
        courseId,
        moduleSeed.moduleNumber,
        moduleSeed.title,
        moduleSeed.sourceBook ?? null,
        moduleSeed.focus ?? null,
        moduleSeed.lockedByDefault,
      ],
    );
    const moduleId = moduleResult.rows[0].id;

    for (const lessonSeed of moduleSeed.lessons) {
      const lessonResult = await client.query<{ id: string }>(
        `
          insert into "Lesson" (
            "id", "moduleId", "lessonNumber", "title", "variants", "isExam", "lockedByDefault", "createdAt", "updatedAt"
          )
          values ($1, $2, $3, $4, $5, $6, $7, now(), now())
          on conflict ("moduleId", "lessonNumber")
          do update set
            "title" = excluded."title",
            "variants" = excluded."variants",
            "isExam" = excluded."isExam",
            "lockedByDefault" = excluded."lockedByDefault",
            "updatedAt" = now()
          returning "id"
        `,
        [
          randomUUID(),
          moduleId,
          lessonSeed.lessonNumber,
          lessonSeed.title,
          lessonSeed.variants,
          lessonSeed.isExam,
          lessonSeed.lockedByDefault,
        ],
      );
      const lessonId = lessonResult.rows[0].id;
      lessonCount += 1;

      const sections = [
        ["grammar", "Grammar"],
        ["vocabulary", "Vocabulary"],
        ["exercises", "Exercises"],
        ["summary", "Summary"],
        ["pronunciation", "Pronunciation"],
      ];

      for (const [index, section] of sections.entries()) {
        await client.query(
          `
            insert into "LessonSection" (
              "id", "lessonId", "type", "title", "orderIndex", "contentJson", "createdAt", "updatedAt"
            )
            select $1, $2, $3, $4, $5, '{}'::jsonb, now(), now()
            where not exists (
              select 1 from "LessonSection" where "lessonId" = $2 and "type" = $3::"LessonSectionType"
            )
          `,
          [randomUUID(), lessonId, section[0], section[1], index],
        );
      }
    }
  }

  await client.query("commit");
  await client.end();

  console.log(`Seeded ${seed.modules.length} modules and ${lessonCount} lessons.`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
