import { Injectable, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import OpenAI from "openai";

import { SupabaseStorageService } from "../storage/supabase-storage.service";
import {
  PronunciationScorer,
  PronunciationScoringInput,
  PronunciationScoringResult,
} from "./pronunciation-scorer";

@Injectable()
export class OpenAiPronunciationScorer extends PronunciationScorer {
  private readonly client?: OpenAI;
  private readonly transcribeModel: string;
  private readonly scoringModel: string;

  constructor(
    private readonly config: ConfigService,
    private readonly storage: SupabaseStorageService,
  ) {
    super();

    const apiKey = this.config.get<string>("OPENAI_API_KEY");
    this.transcribeModel = this.config.get<string>("OPENAI_TRANSCRIBE_MODEL") ?? "gpt-4o-mini-transcribe";
    this.scoringModel = this.config.get<string>("OPENAI_SCORING_MODEL") ?? "gpt-4o-mini";

    if (apiKey) {
      this.client = new OpenAI({ apiKey });
    }
  }

  async score(input: PronunciationScoringInput): Promise<PronunciationScoringResult> {
    const client = this.requireClient();
    const transcript = input.transcript ?? (await this.transcribe(client, input.fileUrl));

    const response = await client.chat.completions.create({
      model: this.scoringModel,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You are an Arabic pronunciation coach for Dutch learners. Score the learner against the expected Arabic prompt. Return only valid JSON.",
        },
        {
          role: "user",
          content: JSON.stringify({
            expectedArabic: input.expectedText,
            learnerTranscript: transcript,
            rubric: {
              overallScore: "0 to 1",
              accuracyScore: "0 to 1, correctness of pronounced sounds/word",
              fluencyScore: "0 to 1, smoothness/naturalness based on transcript evidence",
              completionScore: "0 to 1, whether the whole prompt was attempted",
              feedback: {
                summary: "short learner-friendly Dutch feedback",
                nextStep: "one concrete next practice step in Dutch",
              },
            },
          }),
        },
      ],
    });

    const content = response.choices[0]?.message.content;
    if (!content) throw new ServiceUnavailableException("OpenAI scoring returned no content");

    return this.normalizeResult(JSON.parse(content));
  }

  private async transcribe(client: OpenAI, fileUrl: string) {
    const downloadUrl = await this.toDownloadUrl(fileUrl);
    const response = await fetch(downloadUrl);

    if (!response.ok) {
      throw new ServiceUnavailableException("Could not download recording for transcription");
    }

    const file = new File([await response.blob()], "recording.webm");
    const transcription = await client.audio.transcriptions.create({
      file,
      model: this.transcribeModel,
      language: "ar",
      response_format: "json",
    });

    return transcription.text;
  }

  private async toDownloadUrl(fileUrl: string) {
    const storagePath = this.storage.parseStorageUrl(fileUrl);
    if (storagePath) return this.storage.createSignedDownload(storagePath);
    return fileUrl;
  }

  private normalizeResult(value: unknown): PronunciationScoringResult {
    const result = value as Partial<PronunciationScoringResult>;

    return {
      overallScore: this.clamp(result.overallScore),
      accuracyScore: this.clamp(result.accuracyScore),
      fluencyScore: this.clamp(result.fluencyScore),
      completionScore: this.clamp(result.completionScore),
      feedback: {
        summary: result.feedback?.summary ?? "Je uitspraak is beoordeeld.",
        nextStep: result.feedback?.nextStep ?? "Luister opnieuw en probeer het nog een keer.",
      },
    };
  }

  private clamp(value: unknown) {
    const number = typeof value === "number" ? value : Number(value);
    if (Number.isNaN(number)) return 0;
    return Math.max(0, Math.min(1, number));
  }

  private requireClient() {
    if (!this.client) {
      throw new ServiceUnavailableException("OpenAI is not configured");
    }

    return this.client;
  }
}

