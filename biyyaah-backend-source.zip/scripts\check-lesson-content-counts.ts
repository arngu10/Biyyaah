import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const moduleNumber = Number(process.argv[2] ?? 1);
  const lessonNumber = Number(process.argv[3] ?? 1);
  const client = new pg.Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  const result = await client.query(
    `
      select
        l."title",
        (select count(*)::int from "LessonSection" where "lessonId" = l."id") as sections,
        (select count(*)::int from "GrammarTopic" where "lessonId" = l."id") as grammar_topics,
        (select count(*)::int from "VocabularyItem" where "lessonId" = l."id") as vocabulary_items,
        (select count(*)::int from "Flashcard" where "lessonId" = l."id") as flashcards,
        (select count(*)::int from "PronunciationPrompt" where "lessonId" = l."id") as pronunciation_prompts,
        (select count(*)::int from "Exercise" where "lessonId" = l."id") as exercises,
        (
          select count(*)::int
          from "ExerciseQuestion" q
          join "Exercise" e on e."id" = q."exerciseId"
          where e."lessonId" = l."id"
        ) as exercise_questions
      from "Lesson" l
      join "Module" m on m."id" = l."moduleId"
      join "Course" c on c."id" = m."courseId"
      where c."slug" = 'biyyaah-medina-arabic'
        and m."moduleNumber" = $1
        and l."lessonNumber" = $2
    `,
    [moduleNumber, lessonNumber],
  );

  console.log(result.rows[0] ?? {});
  await client.end();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
