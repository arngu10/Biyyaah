import { Body, Controller, Post } from "@nestjs/common";

import { ProgressService } from "./progress.service";

@Controller("progress")
export class DemoProgressController {
  constructor(private readonly progressService: ProgressService) {}

  @Post("demo-user")
  createDemoUser(@Body() body: { email?: string }) {
    return this.progressService.ensureDemoUser(body.email);
  }
}
