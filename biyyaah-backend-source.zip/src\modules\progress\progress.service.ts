import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { LessonSectionType, ProgressStatus } from "@prisma/client";

import { PrismaService } from "../../prisma/prisma.service";

@Injectable()
export class ProgressService {
  constructor(private readonly prisma: PrismaService) {}

  async ensureDemoUser(email = "demo@biyyaah.local") {
    const user = await this.prisma.user.upsert({
      where: { email },
      update: {},
      create: {
        id: "demo-user",
        email,
        displayName: "Demo Learner",
        profile: {
          create: {
            goal: "medina_arabic",
            startingLevel: "beginner",
            nativeLanguage: "nl",
            dailyLearningMinutes: 20,
            onboardingCompletedAt: new Date(),
          },
        },
      },
      include: { profile: true },
    });

    await this.initializeProgress(user.id);
    return user;
  }

  async getUserProgress(userId: string) {
    await this.ensureUserExists(userId);

    return this.prisma.course.findMany({
      include: {
        modules: {
          orderBy: { moduleNumber: "asc" },
          include: {
            progress: {
              where: { userId },
            },
            lessons: {
              orderBy: { lessonNumber: "asc" },
              include: {
                progress: {
                  where: { userId },
                },
              },
            },
          },
        },
      },
    });
  }

  async getDashboardSummary(userId: string) {
    await this.ensureUserExists(userId);
    await this.initializeProgress(userId);

    const now = new Date();
    const weekStart = this.startOfWeek(now);

    const [
      user,
      totalLessons,
      completedLessons,
      inProgressLessons,
      totalWords,
      reviewedFlashcards,
      attempts,
      streak,
      modules,
      lessonProgress,
      weeklyCompletions,
      certificates,
    ] = await Promise.all([
      this.prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          email: true,
          displayName: true,
          profile: true,
        },
      }),
      this.prisma.lesson.count(),
      this.prisma.lessonProgress.count({
        where: { userId, status: ProgressStatus.completed },
      }),
      this.prisma.lessonProgress.count({
        where: { userId, status: ProgressStatus.in_progress },
      }),
      this.prisma.vocabularyItem.count(),
      this.prisma.flashcardReview.findMany({
        where: { userId },
        distinct: ["flashcardId"],
        select: { flashcardId: true },
      }),
      this.prisma.exerciseAttempt.count({ where: { userId } }),
      this.prisma.streak.findUnique({ where: { userId } }),
      this.prisma.module.findMany({
        orderBy: { moduleNumber: "asc" },
        include: {
          lessons: {
            orderBy: { lessonNumber: "asc" },
            select: { id: true },
          },
          progress: {
            where: { userId },
          },
        },
      }),
      this.prisma.lessonProgress.findMany({
        where: {
          userId,
          status: { in: [ProgressStatus.unlocked, ProgressStatus.in_progress] },
        },
        include: {
          lesson: {
            include: {
              module: true,
              vocabularyItems: {
                orderBy: { orderIndex: "asc" },
                take: 5,
              },
            },
          },
        },
      }),
      this.prisma.lessonProgress.findMany({
        where: {
          userId,
          completedAt: {
            gte: weekStart,
          },
        },
        select: {
          completedAt: true,
          lesson: {
            select: {
              estimatedMinutes: true,
            },
          },
        },
      }),
      this.prisma.certificate.findMany({
        where: { userId },
        include: { module: true },
        orderBy: { issuedAt: "desc" },
      }),
    ]);

    const learnedWords = reviewedFlashcards.length;
    const xp = completedLessons * 20 + learnedWords * 2 + attempts * 5;
    const level = Math.floor(xp / 500) + 1;
    const xpInLevel = xp % 500;
    const nextLesson = this.pickNextLesson(lessonProgress);
    const weeklyActivity = this.buildWeeklyActivity(weekStart, weeklyCompletions);

    return {
      user,
      stats: {
        streakDays: streak?.currentStreakDays ?? 0,
        longestStreakDays: streak?.longestStreakDays ?? 0,
        xp,
        level,
        xpInLevel,
        xpForNextLevel: 500,
        completedLessons,
        totalLessons,
        inProgressLessons,
        learnedWords,
        totalWords,
        studyMinutesThisWeek: weeklyActivity.reduce((total, day) => total + day.studyMinutes, 0),
      },
      nextLesson,
      weeklyActivity,
      modules: modules.map((module) => {
        const progress = module.progress[0];
        const completedLessonsCount = progress?.completedLessonsCount ?? 0;
        const totalModuleLessons = module.lessons.length;

        return {
          id: module.id,
          moduleNumber: module.moduleNumber,
          title: module.title,
          sourceBook: module.sourceBook,
          focus: module.focus,
          status: progress?.status ?? ProgressStatus.locked,
          completedLessonsCount,
          totalLessons: totalModuleLessons,
          progressPercent: totalModuleLessons === 0 ? 0 : Math.round((completedLessonsCount / totalModuleLessons) * 100),
        };
      }),
      certificates: certificates.map((certificate) => ({
        id: certificate.id,
        moduleId: certificate.moduleId,
        moduleNumber: certificate.module.moduleNumber,
        moduleTitle: certificate.module.title,
        certificateUrl: certificate.certificateUrl,
        issuedAt: certificate.issuedAt,
      })),
      recentVocabulary: nextLesson?.vocabularyItems ?? [],
    };
  }

  async startLesson(userId: string, lessonId: string) {
    await this.ensureUserExists(userId);
    const lesson = await this.getLessonOrThrow(lessonId);
    const progress = await this.getLessonProgress(userId, lessonId);

    if (progress?.status === ProgressStatus.locked) {
      throw new BadRequestException("Lesson is locked");
    }

    await this.prisma.moduleProgress.upsert({
      where: {
        userId_moduleId: {
          userId,
          moduleId: lesson.moduleId,
        },
      },
      update: { status: ProgressStatus.in_progress },
      create: {
        userId,
        moduleId: lesson.moduleId,
        status: ProgressStatus.in_progress,
      },
    });

    return this.prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId,
          lessonId,
        },
      },
      update: { status: ProgressStatus.in_progress },
      create: {
        userId,
        lessonId,
        status: ProgressStatus.in_progress,
      },
    });
  }

  async completeSection(userId: string, lessonId: string, sectionType: string) {
    await this.ensureUserExists(userId);
    await this.getLessonOrThrow(lessonId);

    const now = new Date();
    const data = this.sectionCompletionData(sectionType, now);

    return this.prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId,
          lessonId,
        },
      },
      update: data,
      create: {
        userId,
        lessonId,
        status: ProgressStatus.in_progress,
        ...data,
      },
    });
  }

  async completeLesson(userId: string, lessonId: string) {
    await this.ensureUserExists(userId);
    const lesson = await this.getLessonOrThrow(lessonId);
    const now = new Date();

    const completed = await this.prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId,
          lessonId,
        },
      },
      update: {
        status: ProgressStatus.completed,
        completedAt: now,
      },
      create: {
        userId,
        lessonId,
        status: ProgressStatus.completed,
        completedAt: now,
      },
    });

    await this.unlockNextLesson(userId, lesson.moduleId, lesson.lessonNumber);
    await this.updateModuleProgress(userId, lesson.moduleId);
    await this.updateStreak(userId, now);

    return completed;
  }

  async initializeProgress(userId: string) {
    const modules = await this.prisma.module.findMany({
      orderBy: { moduleNumber: "asc" },
      include: {
        lessons: {
          orderBy: { lessonNumber: "asc" },
        },
      },
    });

    for (const module of modules) {
      const moduleUnlocked = module.moduleNumber === 1;
      await this.prisma.moduleProgress.upsert({
        where: {
          userId_moduleId: {
            userId,
            moduleId: module.id,
          },
        },
        update: {},
        create: {
          userId,
          moduleId: module.id,
          status: moduleUnlocked ? ProgressStatus.unlocked : ProgressStatus.locked,
        },
      });

      for (const lesson of module.lessons) {
        const lessonUnlocked = module.moduleNumber === 1 && lesson.lessonNumber === 1;
        await this.prisma.lessonProgress.upsert({
          where: {
            userId_lessonId: {
              userId,
              lessonId: lesson.id,
            },
          },
          update: {},
          create: {
            userId,
            lessonId: lesson.id,
            status: lessonUnlocked ? ProgressStatus.unlocked : ProgressStatus.locked,
          },
        });
      }
    }
  }

  private async ensureUserExists(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true },
    });

    if (!user) {
      return this.ensureDemoUser();
    }

    return user;
  }

  private getLessonProgress(userId: string, lessonId: string) {
    return this.prisma.lessonProgress.findUnique({
      where: {
        userId_lessonId: {
          userId,
          lessonId,
        },
      },
    });
  }

  private async getLessonOrThrow(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");
    return lesson;
  }

  private sectionCompletionData(sectionType: string, completedAt: Date) {
    switch (sectionType) {
      case LessonSectionType.grammar:
        return { grammarCompletedAt: completedAt };
      case LessonSectionType.vocabulary:
        return { vocabularyCompletedAt: completedAt };
      case LessonSectionType.exercises:
        return { exercisesCompletedAt: completedAt };
      case LessonSectionType.summary:
        return { summaryCompletedAt: completedAt };
      case LessonSectionType.pronunciation:
        return { pronunciationCompletedAt: completedAt };
      default:
        throw new BadRequestException("Unknown section type");
    }
  }

  private async unlockNextLesson(userId: string, moduleId: string, lessonNumber: number) {
    const nextLesson = await this.prisma.lesson.findUnique({
      where: {
        moduleId_lessonNumber: {
          moduleId,
          lessonNumber: lessonNumber + 1,
        },
      },
    });

    if (!nextLesson) return;

    await this.prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId,
          lessonId: nextLesson.id,
        },
      },
      update: { status: ProgressStatus.unlocked },
      create: {
        userId,
        lessonId: nextLesson.id,
        status: ProgressStatus.unlocked,
      },
    });
  }

  private async updateModuleProgress(userId: string, moduleId: string) {
    const [lessons, completedLessons] = await Promise.all([
      this.prisma.lesson.count({ where: { moduleId } }),
      this.prisma.lessonProgress.count({
        where: {
          userId,
          lesson: { moduleId },
          status: ProgressStatus.completed,
        },
      }),
    ]);

    const status =
      lessons > 0 && completedLessons === lessons ? ProgressStatus.completed : ProgressStatus.in_progress;

    await this.prisma.moduleProgress.upsert({
      where: {
        userId_moduleId: {
          userId,
          moduleId,
        },
      },
      update: {
        completedLessonsCount: completedLessons,
        status,
        completedAt: status === ProgressStatus.completed ? new Date() : null,
      },
      create: {
        userId,
        moduleId,
        completedLessonsCount: completedLessons,
        status,
        completedAt: status === ProgressStatus.completed ? new Date() : null,
      },
    });

    if (status === ProgressStatus.completed) {
      await this.issueCertificate(userId, moduleId);
      await this.unlockNextModule(userId, moduleId);
    }
  }

  private async issueCertificate(userId: string, moduleId: string) {
    const existing = await this.prisma.certificate.findFirst({
      where: { userId, moduleId },
      select: { id: true },
    });

    if (existing) return existing;

    return this.prisma.certificate.create({
      data: { userId, moduleId },
    });
  }

  private async unlockNextModule(userId: string, moduleId: string) {
    const module = await this.prisma.module.findUnique({
      where: { id: moduleId },
    });

    if (!module) return;

    const nextModule = await this.prisma.module.findUnique({
      where: {
        courseId_moduleNumber: {
          courseId: module.courseId,
          moduleNumber: module.moduleNumber + 1,
        },
      },
      include: {
        lessons: {
          orderBy: { lessonNumber: "asc" },
          take: 1,
        },
      },
    });

    if (!nextModule) return;

    await this.prisma.moduleProgress.upsert({
      where: {
        userId_moduleId: {
          userId,
          moduleId: nextModule.id,
        },
      },
      update: { status: ProgressStatus.unlocked },
      create: {
        userId,
        moduleId: nextModule.id,
        status: ProgressStatus.unlocked,
      },
    });

    const firstLesson = nextModule.lessons[0];
    if (!firstLesson) return;

    await this.prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId,
          lessonId: firstLesson.id,
        },
      },
      update: { status: ProgressStatus.unlocked },
      create: {
        userId,
        lessonId: firstLesson.id,
        status: ProgressStatus.unlocked,
      },
    });
  }

  private async updateStreak(userId: string, activityDate: Date) {
    const today = new Date(activityDate.toDateString());
    const streak = await this.prisma.streak.findUnique({ where: { userId } });

    if (!streak?.lastActivityDate) {
      return this.prisma.streak.upsert({
        where: { userId },
        update: {
          currentStreakDays: 1,
          longestStreakDays: Math.max(streak?.longestStreakDays ?? 0, 1),
          lastActivityDate: today,
        },
        create: {
          userId,
          currentStreakDays: 1,
          longestStreakDays: 1,
          lastActivityDate: today,
        },
      });
    }

    const last = new Date(streak.lastActivityDate.toDateString());
    const dayMs = 24 * 60 * 60 * 1000;
    const diffDays = Math.round((today.getTime() - last.getTime()) / dayMs);

    if (diffDays === 0) return streak;

    const currentStreakDays = diffDays === 1 ? streak.currentStreakDays + 1 : 1;

    return this.prisma.streak.update({
      where: { userId },
      data: {
        currentStreakDays,
        longestStreakDays: Math.max(streak.longestStreakDays, currentStreakDays),
        lastActivityDate: today,
      },
    });
  }

  private pickNextLesson(
    lessonProgress: Array<{
      status: ProgressStatus;
      lesson: {
        id: string;
        lessonNumber: number;
        title: string;
        estimatedMinutes: number | null;
        vocabularyItems: Array<{
          id: string;
          arabic: string;
          transliteration: string | null;
          dutchMeaning: string;
          notes: string | null;
          orderIndex: number;
          audioAssetId: string | null;
          lessonId: string;
        }>;
        module: {
          id: string;
          moduleNumber: number;
          title: string;
        };
      };
    }>,
  ) {
    const sorted = [...lessonProgress].sort((a, b) => {
      if (a.status !== b.status) {
        return a.status === ProgressStatus.in_progress ? -1 : 1;
      }

      if (a.lesson.module.moduleNumber !== b.lesson.module.moduleNumber) {
        return a.lesson.module.moduleNumber - b.lesson.module.moduleNumber;
      }

      return a.lesson.lessonNumber - b.lesson.lessonNumber;
    });

    const progress = sorted[0];
    if (!progress) return null;

    return {
      id: progress.lesson.id,
      lessonNumber: progress.lesson.lessonNumber,
      title: progress.lesson.title,
      estimatedMinutes: progress.lesson.estimatedMinutes,
      status: progress.status,
      module: progress.lesson.module,
      vocabularyItems: progress.lesson.vocabularyItems,
    };
  }

  private startOfWeek(date: Date) {
    const result = new Date(date);
    const day = result.getDay() || 7;
    result.setHours(0, 0, 0, 0);
    result.setDate(result.getDate() - day + 1);
    return result;
  }

  private buildWeeklyActivity(
    weekStart: Date,
    completions: Array<{
      completedAt: Date | null;
      lesson: {
        estimatedMinutes: number | null;
      };
    }>,
  ) {
    const labels = ["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"];
    const days = labels.map((label, index) => {
      const date = new Date(weekStart);
      date.setDate(weekStart.getDate() + index);

      return {
        label,
        date: date.toISOString().slice(0, 10),
        completedLessons: 0,
        studyMinutes: 0,
      };
    });

    for (const completion of completions) {
      if (!completion.completedAt) continue;

      const dayIndex = Math.floor(
        (new Date(completion.completedAt).setHours(0, 0, 0, 0) - weekStart.getTime()) / (24 * 60 * 60 * 1000),
      );

      if (dayIndex < 0 || dayIndex >= days.length) continue;

      days[dayIndex].completedLessons += 1;
      days[dayIndex].studyMinutes += completion.lesson.estimatedMinutes ?? 15;
    }

    return days;
  }
}
