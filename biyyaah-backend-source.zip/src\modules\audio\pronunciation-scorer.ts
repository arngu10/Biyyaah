export type PronunciationScoringInput = {
  expectedText: string;
  transcript?: string;
  fileUrl: string;
};

export type PronunciationScoringResult = {
  overallScore: number;
  accuracyScore: number;
  fluencyScore: number;
  completionScore: number;
  feedback: {
    summary: string;
    nextStep: string;
  };
};

export abstract class PronunciationScorer {
  abstract score(input: PronunciationScoringInput): Promise<PronunciationScoringResult>;
}

