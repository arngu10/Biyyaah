# Supabase Setup

Project: Biyyaah

## Storage

The backend is configured to use a private Supabase Storage bucket:

```text
audio
```

This bucket stores:

- generated reference pronunciation audio
- human-reviewed reference audio later
- learner recordings

Verification command:

```powershell
npm --workspace apps/api run supabase:check
```

## Database

Supabase should also be used as the first hosted Postgres database.

In Supabase:

1. Open Project Settings.
2. Go to Database.
3. Copy the connection string for direct connection or pooled connection.
4. Put it into `apps/api/.env` as `DATABASE_URL`.

For local development, direct connection is easiest. For deployed serverless environments, use the pooled connection.

After `DATABASE_URL` is set:

```powershell
npm run api:migrate
npm run api:seed
```

This creates the schema and seeds:

- 1 course
- 4 modules
- 92 lessons
- 5 empty lesson sections per lesson

## Production Note

The Supabase service role key is powerful. It must only be used by the backend, never by browser/frontend code. Rotate it before production because it was shared during setup.

