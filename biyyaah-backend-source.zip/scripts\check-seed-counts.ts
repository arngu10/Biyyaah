import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const client = new pg.Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  const result = await client.query(`
    select
      (select count(*)::int from "Course") as courses,
      (select count(*)::int from "Module") as modules,
      (select count(*)::int from "Lesson") as lessons,
      (select count(*)::int from "LessonSection") as sections
  `);
  console.log(result.rows[0]);
  await client.end();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
