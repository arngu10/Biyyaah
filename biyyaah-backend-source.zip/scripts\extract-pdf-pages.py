from pathlib import Path
import argparse

from pypdf import PdfReader


DEFAULT_SOURCE = Path(r"C:\Users\tima_\Downloads\Medina Boek 1 Nederlands (1).pdf")
DEFAULT_OUTPUT_DIR = Path(r"C:\Users\tima_\Documents\Codex\Biyyaah\content\book-1-pages")


parser = argparse.ArgumentParser(description="Extract embedded page images from a scanned PDF.")
parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
parser.add_argument("--prefix", default="book-1-page")
parser.add_argument("--start", type=int, required=True)
parser.add_argument("--end", type=int, required=True, help="Inclusive PDF page number.")
args = parser.parse_args()

args.output_dir.mkdir(parents=True, exist_ok=True)
reader = PdfReader(args.source)

for page_number in range(args.start, args.end + 1):
    page = reader.pages[page_number - 1]
    images = list(page.images)
    if not images:
        print(f"page {page_number}: no images")
        continue

    image = images[0]
    extension = Path(image.name).suffix or ".png"
    output = args.output_dir / f"{args.prefix}-{page_number:03d}{extension}"
    output.write_bytes(image.data)
    print(output)
