import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";

import { AuthTokenService } from "./auth-token.service";

@Injectable()
export class BearerAuthGuard implements CanActivate {
  constructor(private readonly tokens: AuthTokenService) {}

  canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<{
      headers: { authorization?: string };
      userId?: string;
    }>();
    const payload = this.tokens.verifyAuthorizationHeader(request.headers.authorization);

    request.userId = payload.sub;
    return true;
  }
}

