import { Injectable } from "@nestjs/common";

import { PrismaService } from "../../prisma/prisma.service";
import { UpdateProfileDto } from "./dto/update-profile.dto";

@Injectable()
export class ProfilesService {
  constructor(private readonly prisma: PrismaService) {}

  getProfile(userId: string) {
    return this.prisma.userProfile.findUnique({
      where: { userId },
    });
  }

  updateProfile(userId: string, body: UpdateProfileDto) {
    return this.prisma.userProfile.upsert({
      where: { userId },
      update: body,
      create: {
        userId,
        ...body,
      },
    });
  }

  completeOnboarding(userId: string, body: UpdateProfileDto) {
    return this.prisma.userProfile.upsert({
      where: { userId },
      update: {
        ...body,
        onboardingCompletedAt: new Date(),
      },
      create: {
        userId,
        ...body,
        onboardingCompletedAt: new Date(),
      },
    });
  }
}
