import { readFileSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required");

  const migrationPath = join(__dirname, "..", "prisma", "migrations", "000001_init", "migration.sql");
  const sql = readFileSync(migrationPath, "utf-8").replace(/^\uFEFF/, "");
  const client = new pg.Client({
    connectionString,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  await client.query("begin");
  await client.query(sql);
  await client.query(`
    create table if not exists "_prisma_migrations" (
      id varchar(36) primary key,
      checksum varchar(64) not null,
      finished_at timestamptz,
      migration_name varchar(255) not null,
      logs text,
      rolled_back_at timestamptz,
      started_at timestamptz not null default now(),
      applied_steps_count integer not null default 0
    )
  `);
  await client.query(`
    insert into "_prisma_migrations" (
      id,
      checksum,
      finished_at,
      migration_name,
      logs,
      rolled_back_at,
      started_at,
      applied_steps_count
    )
    values (
      '000001_init_manual',
      'manual',
      now(),
      '000001_init',
      null,
      null,
      now(),
      1
    )
    on conflict (id) do nothing
  `);
  await client.query("commit");
  await client.end();
  console.log("Applied initial migration SQL.");
}

main().catch(async (error) => {
  console.error(error);
  process.exit(1);
});
