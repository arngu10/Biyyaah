import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "node:fs";
import { join } from "node:path";

function loadEnv() {
  const envPath = join(__dirname, "..", ".env");
  const env = readFileSync(envPath, "utf-8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const [, key, rawValue] = match;
    process.env[key] = rawValue.replace(/^"|"$/g, "");
  }
}

async function main() {
  loadEnv();

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_AUDIO_BUCKET ?? "audio";

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required.");
  }

  const client = createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const { data: buckets, error: listError } = await client.storage.listBuckets();
  if (listError) throw listError;

  if (!buckets.some((item) => item.name === bucket)) {
    const { error: createError } = await client.storage.createBucket(bucket, {
      public: false,
      fileSizeLimit: 25 * 1024 * 1024,
      allowedMimeTypes: ["audio/webm", "audio/wav", "audio/mpeg", "audio/mp4", "audio/x-m4a"],
    });

    if (createError) throw createError;
    console.log(`Created private bucket "${bucket}".`);
  } else {
    console.log(`Found bucket "${bucket}".`);
  }

  const testPath = `healthcheck/${Date.now()}-recording.webm`;
  const { data: upload, error: uploadError } = await client.storage.from(bucket).createSignedUploadUrl(testPath);
  if (uploadError) throw uploadError;

  console.log(`Signed upload URL created for ${testPath}.`);
  console.log(`Token present: ${Boolean(upload.token)}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
