# Biyyaah

Biyyaah is a Dutch-market Arabic learning app built around the Medina curriculum.

This repo starts with the backend API foundation:

- NestJS API
- Prisma/PostgreSQL data model
- Course/module/lesson seed data
- Structured Lesson 1 content seed with grammar, vocabulary, flashcards, exercises, and pronunciation prompts
- Learner progress and unlock logic
- Future modules for Stripe billing, audio, and AI pronunciation scoring

## Structure

```text
apps/api       Backend API
apps/web       Static frontend prototype
docs           Product and backend notes
```

## First Backend Milestone

1. Install dependencies.
2. Configure `DATABASE_URL`.
3. Run Prisma migrations.
4. Seed the course outline from `apps/api/prisma/seed-data/lesson-outline.json`.
5. Seed lesson content from `apps/api/prisma/seed-data/lesson-1-content.json`.
6. Serve content and learner progress APIs.

## Local API Setup

If Docker is available:

```powershell
docker compose up -d postgres
npm run api:migrate
npm run api:seed
npm run api:dev
```

The API runs on `http://localhost:4000/api`.

## Supabase Seed Commands

```powershell
npm.cmd --workspace apps/api run db:apply-sql
npm.cmd --workspace apps/api run db:seed-sql
npm.cmd --workspace apps/api run db:seed-content-sql
npm.cmd --workspace apps/api run db:seed-content-sql -- lesson-2-content.json
npm.cmd --workspace apps/api run db:seed-all-content-sql
npm.cmd --workspace apps/api run db:lesson-counts -- 1 1
```

## Local Web App

With the API running:

```powershell
npm.cmd run web:dev
```

The web app runs on `http://localhost:3000`.

## Supabase

Supabase setup notes live in:

[docs/supabase-setup.md](docs/supabase-setup.md)
