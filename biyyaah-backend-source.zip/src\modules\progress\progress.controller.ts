import { Controller, Get, Param, Patch, Post, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { ProgressService } from "./progress.service";

@Controller()
@UseGuards(BearerAuthGuard)
export class ProgressController {
  constructor(private readonly progressService: ProgressService) {}

  @Get("me/progress")
  getMyProgress(@CurrentUserId() userId: string) {
    return this.progressService.getUserProgress(userId);
  }

  @Get("me/dashboard")
  getMyDashboard(@CurrentUserId() userId: string) {
    return this.progressService.getDashboardSummary(userId);
  }

  @Get("me/progress/summary")
  getMyProgressSummary(@CurrentUserId() userId: string) {
    return this.progressService.getDashboardSummary(userId);
  }

  @Post("lessons/:lessonId/start")
  startLesson(@CurrentUserId() userId: string, @Param("lessonId") lessonId: string) {
    return this.progressService.startLesson(userId, lessonId);
  }

  @Patch("lessons/:lessonId/sections/:sectionType/complete")
  completeSection(
    @CurrentUserId() userId: string,
    @Param("lessonId") lessonId: string,
    @Param("sectionType") sectionType: string,
  ) {
    return this.progressService.completeSection(userId, lessonId, sectionType);
  }

  @Post("lessons/:lessonId/complete")
  completeLesson(@CurrentUserId() userId: string, @Param("lessonId") lessonId: string) {
    return this.progressService.completeLesson(userId, lessonId);
  }
}
