import { Injectable, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { createClient, SupabaseClient } from "@supabase/supabase-js";

@Injectable()
export class SupabaseStorageService {
  private readonly bucket: string;
  private readonly client?: SupabaseClient;

  constructor(config: ConfigService) {
    const supabaseUrl = config.get<string>("SUPABASE_URL");
    const serviceRoleKey = config.get<string>("SUPABASE_SERVICE_ROLE_KEY");

    this.bucket = config.get<string>("SUPABASE_AUDIO_BUCKET") ?? "audio";

    if (supabaseUrl && serviceRoleKey) {
      this.client = createClient(supabaseUrl, serviceRoleKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      });
    }
  }

  async createSignedUpload(path: string) {
    const client = this.requireClient();
    const { data, error } = await client.storage.from(this.bucket).createSignedUploadUrl(path);

    if (error) throw new ServiceUnavailableException(error.message);

    return {
      bucket: this.bucket,
      path,
      signedUrl: data.signedUrl,
      token: data.token,
      fileUrl: this.toStorageUrl(path),
    };
  }

  async createSignedDownload(path: string, expiresInSeconds = 60 * 10) {
    const client = this.requireClient();
    const { data, error } = await client.storage.from(this.bucket).createSignedUrl(path, expiresInSeconds);

    if (error) throw new ServiceUnavailableException(error.message);

    return data.signedUrl;
  }

  async upload(path: string, body: ArrayBuffer | Buffer, contentType: string) {
    const client = this.requireClient();
    const { error } = await client.storage.from(this.bucket).upload(path, body, {
      contentType,
      upsert: true,
    });

    if (error) throw new ServiceUnavailableException(error.message);

    return {
      bucket: this.bucket,
      path,
      fileUrl: this.toStorageUrl(path),
    };
  }

  toStorageUrl(path: string) {
    return `supabase://${this.bucket}/${path}`;
  }

  parseStorageUrl(fileUrl: string) {
    const prefix = `supabase://${this.bucket}/`;
    if (!fileUrl.startsWith(prefix)) return null;
    return fileUrl.slice(prefix.length);
  }

  private requireClient() {
    if (!this.client) {
      throw new ServiceUnavailableException("Supabase storage is not configured");
    }

    return this.client;
  }
}
