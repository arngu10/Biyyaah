import { createParamDecorator, ExecutionContext, UnauthorizedException } from "@nestjs/common";

export const CurrentUserId = createParamDecorator((_data: unknown, context: ExecutionContext) => {
  const request = context.switchToHttp().getRequest<{ userId?: string }>();

  if (!request.userId) {
    throw new UnauthorizedException("Missing authenticated user");
  }

  return request.userId;
});

