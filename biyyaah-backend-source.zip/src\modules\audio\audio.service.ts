import { Injectable, NotFoundException } from "@nestjs/common";
import { Prisma } from "@prisma/client";

import { PrismaService } from "../../prisma/prisma.service";
import { SupabaseStorageService } from "../storage/supabase-storage.service";
import { CreateRecordingDto } from "./dto/create-recording.dto";
import { CreateRecordingUploadDto } from "./dto/create-recording-upload.dto";
import { GenerateReferenceAudioDto } from "./dto/generate-reference-audio.dto";
import { ScoreRecordingDto } from "./dto/score-recording.dto";
import { PronunciationScorer } from "./pronunciation-scorer";
import { ReferenceAudioService } from "./reference-audio.service";

@Injectable()
export class AudioService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly storage: SupabaseStorageService,
    private readonly scorer: PronunciationScorer,
    private readonly referenceAudio: ReferenceAudioService,
  ) {}

  async getPronunciationPrompts(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { id: true },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");

    return this.prisma.pronunciationPrompt.findMany({
      where: { lessonId },
      orderBy: { orderIndex: "asc" },
      include: {
        referenceAudioAsset: true,
        vocabularyItem: true,
      },
    });
  }

  async createRecording(userId: string, promptId: string, body: CreateRecordingDto) {
    const prompt = await this.prisma.pronunciationPrompt.findUnique({
      where: { id: promptId },
      select: { id: true },
    });

    if (!prompt) throw new NotFoundException("Pronunciation prompt not found");

    return this.prisma.userRecording.create({
      data: {
        userId,
        pronunciationPromptId: promptId,
        fileUrl: body.fileUrl,
        durationMs: body.durationMs,
      },
    });
  }

  async createRecordingUpload(userId: string, promptId: string, body: CreateRecordingUploadDto) {
    const prompt = await this.prisma.pronunciationPrompt.findUnique({
      where: { id: promptId },
      select: { id: true },
    });

    if (!prompt) throw new NotFoundException("Pronunciation prompt not found");

    const extension = this.extensionForContentType(body.contentType);
    const safeName = body.fileName?.replace(/[^a-zA-Z0-9._-]/g, "-") ?? `recording.${extension}`;
    const path = `recordings/${userId}/${promptId}/${Date.now()}-${safeName}`;

    return this.storage.createSignedUpload(path);
  }

  generateReferenceAudio(body: GenerateReferenceAudioDto) {
    return this.referenceAudio.generateForText({
      text: body.text,
      languageCode: body.languageCode,
      pathPrefix: "reference/manual",
    });
  }

  async generatePromptReferenceAudio(promptId: string) {
    const prompt = await this.prisma.pronunciationPrompt.findUnique({
      where: { id: promptId },
    });

    if (!prompt) throw new NotFoundException("Pronunciation prompt not found");

    const audioAsset = await this.referenceAudio.generateForText({
      text: prompt.expectedText,
      languageCode: "ar",
      pathPrefix: `reference/prompts/${promptId}`,
    });

    return this.prisma.pronunciationPrompt.update({
      where: { id: promptId },
      data: {
        referenceAudioAssetId: audioAsset.id,
      },
      include: {
        referenceAudioAsset: true,
      },
    });
  }

  async scoreRecording(userId: string, recordingId: string, body: ScoreRecordingDto) {
    const recording = await this.prisma.userRecording.findFirst({
      where: {
        id: recordingId,
        userId,
      },
      include: {
        pronunciationPrompt: true,
      },
    });

    if (!recording) throw new NotFoundException("Recording not found");

    const result = await this.scorer.score({
      expectedText: recording.pronunciationPrompt.expectedText,
      transcript: body.transcript,
      fileUrl: recording.fileUrl,
    });

    return this.prisma.pronunciationScore.create({
      data: {
        userRecordingId: recording.id,
        userId,
        pronunciationPromptId: recording.pronunciationPromptId,
        overallScore: result.overallScore,
        accuracyScore: result.accuracyScore,
        fluencyScore: result.fluencyScore,
        completionScore: result.completionScore,
        feedbackJson: result.feedback as Prisma.InputJsonValue,
      },
    });
  }

  private extensionForContentType(contentType: CreateRecordingUploadDto["contentType"]) {
    const extensions = {
      "audio/webm": "webm",
      "audio/wav": "wav",
      "audio/mpeg": "mp3",
      "audio/mp4": "mp4",
      "audio/x-m4a": "m4a",
    };

    return extensions[contentType];
  }
}
