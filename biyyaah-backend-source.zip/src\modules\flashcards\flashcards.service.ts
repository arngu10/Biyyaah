import { Injectable, NotFoundException } from "@nestjs/common";
import { FlashcardRating } from "@prisma/client";

import { PrismaService } from "../../prisma/prisma.service";
import { ReviewFlashcardDto } from "./dto/review-flashcard.dto";

@Injectable()
export class FlashcardsService {
  constructor(private readonly prisma: PrismaService) {}

  async getLessonFlashcards(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { id: true },
    });

    if (!lesson) throw new NotFoundException("Lesson not found");

    return this.prisma.flashcard.findMany({
      where: { lessonId },
      orderBy: { orderIndex: "asc" },
      include: {
        audioAsset: true,
        vocabularyItem: true,
      },
    });
  }

  async getDueFlashcards(userId: string) {
    const now = new Date();

    const flashcards = await this.prisma.flashcard.findMany({
      orderBy: { orderIndex: "asc" },
      include: {
        audioAsset: true,
        vocabularyItem: true,
        reviews: {
          where: { userId },
          orderBy: { reviewedAt: "desc" },
          take: 1,
        },
      },
    });

    return flashcards.filter((flashcard) => {
      const latestReview = flashcard.reviews[0];

      if (!latestReview) return true;
      if (!latestReview.nextReviewAt) return true;

      return latestReview.nextReviewAt <= now;
    });
  }

  async reviewFlashcard(userId: string, flashcardId: string, body: ReviewFlashcardDto) {
    const flashcard = await this.prisma.flashcard.findUnique({
      where: { id: flashcardId },
      select: { id: true },
    });

    if (!flashcard) throw new NotFoundException("Flashcard not found");

    const reviewedAt = body.clientReviewedAt ? new Date(body.clientReviewedAt) : new Date();
    const nextReviewAt = this.nextReviewDate(body.rating, reviewedAt);

    return this.prisma.flashcardReview.create({
      data: {
        userId,
        flashcardId,
        rating: body.rating as FlashcardRating,
        reviewedAt,
        nextReviewAt,
      },
    });
  }

  private nextReviewDate(rating: ReviewFlashcardDto["rating"], reviewedAt: Date) {
    const dayMs = 24 * 60 * 60 * 1000;
    const intervals = {
      again: 0.25,
      hard: 1,
      good: 3,
      easy: 7,
    };

    return new Date(reviewedAt.getTime() + intervals[rating] * dayMs);
  }
}
