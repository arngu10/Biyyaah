import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";

import { BearerAuthGuard } from "../auth/bearer-auth.guard";
import { CurrentUserId } from "../auth/current-user-id.decorator";
import { ReviewFlashcardDto } from "./dto/review-flashcard.dto";
import { FlashcardsService } from "./flashcards.service";

@Controller()
@UseGuards(BearerAuthGuard)
export class FlashcardsController {
  constructor(private readonly flashcardsService: FlashcardsService) {}

  @Get("lessons/:lessonId/flashcards")
  getLessonFlashcards(@Param("lessonId") lessonId: string) {
    return this.flashcardsService.getLessonFlashcards(lessonId);
  }

  @Get("me/flashcards/due")
  getDueFlashcards(@CurrentUserId() userId: string) {
    return this.flashcardsService.getDueFlashcards(userId);
  }

  @Post("flashcards/:flashcardId/review")
  reviewFlashcard(
    @CurrentUserId() userId: string,
    @Param("flashcardId") flashcardId: string,
    @Body() body: ReviewFlashcardDto,
  ) {
    return this.flashcardsService.reviewFlashcard(userId, flashcardId, body);
  }
}

