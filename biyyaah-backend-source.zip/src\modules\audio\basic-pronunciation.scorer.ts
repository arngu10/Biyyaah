import { Injectable } from "@nestjs/common";

import { PronunciationScorer, PronunciationScoringInput } from "./pronunciation-scorer";

@Injectable()
export class BasicPronunciationScorer extends PronunciationScorer {
  async score(input: PronunciationScoringInput) {
    const normalizedExpected = this.normalize(input.expectedText);
    const normalizedTranscript = this.normalize(input.transcript ?? "");
    const hasTranscript = normalizedTranscript.length > 0;
    const exactMatch = hasTranscript && normalizedExpected === normalizedTranscript;
    const partialMatch =
      hasTranscript &&
      (normalizedExpected.includes(normalizedTranscript) || normalizedTranscript.includes(normalizedExpected));

    const accuracyScore = exactMatch ? 1 : partialMatch ? 0.65 : hasTranscript ? 0.35 : 0.5;
    const fluencyScore = hasTranscript ? 0.7 : 0.5;
    const completionScore = hasTranscript ? Math.min(1, normalizedTranscript.length / normalizedExpected.length) : 0.5;
    const overallScore = Number(((accuracyScore + fluencyScore + completionScore) / 3).toFixed(2));

    return {
      overallScore,
      accuracyScore,
      fluencyScore,
      completionScore,
      feedback: {
        summary: hasTranscript
          ? "We compared your attempt with the target prompt. Full AI pronunciation feedback will replace this baseline scorer."
          : "Recording received. Full AI transcription and pronunciation feedback will run here.",
        nextStep: overallScore >= 0.8 ? "Move to the next prompt." : "Listen again and repeat the prompt slowly.",
      },
    };
  }

  private normalize(value: string) {
    return value
      .trim()
      .replace(/\s+/g, " ")
      .replace(/[ـًٌٍَُِّْ]/g, "");
  }
}
